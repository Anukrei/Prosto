# Animated CSS Gradient Border

A Pen created on CodePen.io. Original URL: [https://codepen.io/mike-schultz/pen/NgQvGO](https://codepen.io/mike-schultz/pen/NgQvGO).

Inspired by the github universe alert: https://s3-us-west-2.amazonaws.com/s.cdpn.io/173256/github-universe.png